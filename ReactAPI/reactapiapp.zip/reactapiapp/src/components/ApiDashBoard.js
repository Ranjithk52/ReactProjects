import React, { Component } from 'react'
import axios from 'axios';

export default class ApiDashBoard extends Component {

    constructor(props) {
        super(props);
        this.state = {
            items: [],
            DataisLoaded: false

        }

    }

    componentDidMount() {

        axios.get("https://fakestoreapi.com/products")
            .then(resp => {
                this.setState({
                    items: resp.data,
                    DataisLoaded: true

                })
            })
    }
    render() {
        return (
            //<div className='row col-12'>
            <div >
                <h1> Fetch data from an api in react </h1>  {
                    this.state.items.map((item) => {
                        return (
                            // <div className="row col-12">

                            //         <div className="col-4">

                            //             <div className="card card-center ">

                            //                 <center> <img src={item.image} alt={item.id} style={{ width: "150px", height: "150px" }}></img></center>

                            //                 <div className="card-body">

                            //                     <h5 className="card-title">{item.id}</h5>

                            //                     <p className="card-text">{item.title}</p>
                            //                     <p className='card-text'>{item.price}</p>


                            //                 </div>

                            //             </div>
                            //             <button className='btn btn-primary'>BUY</button>
                            //         </div>


                            //      </div>
                            
                            <div className="four wide column" key={item.id}>
                                {/* <Link to={`/product/${id}`}> */}
                                    <div className="ui link cards">
                                        <div className="card">
                                            <div className="image">
                                                <img src={item.image} alt={item.title}></img>
                                            </div>
                                            <div className="content">
                                                <div className="header">{item.title}</div>
                                                <div className="meta price">$ {item.price}</div>
                                                <div className="meta">{item.category}</div>
                                            </div>
                                        </div>
                                    </div>
                                {/* </Link> */}
                            </div>


                        )
                    }
                    )
                }
            </div>
            //</div>
        )
    }
}
