import React from 'react'
import { BrowserRouter,Link,Route,Routes } from 'react-router-dom'
import ApiDashBoard from './ApiDashBoard'
import Create from './Create'
import Login from './Login'



function NavBar() {
  return (
    <div>
      <BrowserRouter>
    <ul>
        <li>
            <Link to='/login' className='btn btn-primary' style={{margin:'10px'}}>SignIn</Link>
        </li>
        <li>
        <Link to='/register' className='btn btn-primary' style={{margin:'10px'}}>SignUp</Link>
        </li>
    </ul>

      <Routes>
        <Route path='/login' element={<Login/>}/>
        <Route path='/register' element={<Create/>}/>
        <Route path='/dashboard' element={<ApiDashBoard/>}/>

      </Routes>
      </BrowserRouter>
    </div>
  )
}

export default NavBar
