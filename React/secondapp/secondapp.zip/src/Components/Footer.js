import React, { Component } from 'react'

export class Footer extends Component {
  render() {
    return (
      <div>
        <h1>Footer Components</h1>
      </div>
    )
  }
}

export default Footer
