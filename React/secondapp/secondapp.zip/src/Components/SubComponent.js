import React from 'react'

const SubComponent = () => {
  return (
    <div>
      <h1>ArrowFunction Component</h1>
    </div>
  )
}

export default SubComponent
