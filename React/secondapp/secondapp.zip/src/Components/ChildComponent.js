import React from 'react'

function ChildComponent() {
  return (
    <div>
      <h1>Functional Component</h1>
    </div>
  )
}

export default ChildComponent
