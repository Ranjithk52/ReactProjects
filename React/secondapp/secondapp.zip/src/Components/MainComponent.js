import React, { Component } from 'react'

export class MainComponent extends Component {
  render() {
    return (
      <div>
        <h1>Main Component</h1>
      </div>
    )
  }
}

export default MainComponent
