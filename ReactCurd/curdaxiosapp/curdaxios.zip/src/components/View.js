import React from 'react'

function View() {
  return (
    <div>
      
    </div>
  )
}

export default View

