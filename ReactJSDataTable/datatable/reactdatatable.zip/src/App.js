
import './App.css';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import ListComponent from './components/ListComponent';

function App() {
  return (
    <div className="App">
      <ListComponent/>
    </div>
  );
}

export default App;
