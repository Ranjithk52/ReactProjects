
import './App.css';
import Channel from './components/Channel';
import InriDcri from './components/InriDcri';
//import Products from './components/Products';


function App() {
  return (
    <div className="App">
      {/* <h1>Products</h1><hr/>
      <img src=""></img><Products  id="2" name="abc" qty="25"/>
      <img src="C:\Users\rk22032\Desktop\Routerapp\state_props\public\assets\img1.jpg"></img><Products  id="3" name="pqr" qty="36"/>
      <img src="C:\Users\rk22032\Desktop\Routerapp\state_props\public\assets\img1.jpg"></img><Products  id="4" name="xyz" qty="48"/> */}
      {/* <InriDcri/> */}
      <Channel/>
    </div>
  );
}

export default App;
