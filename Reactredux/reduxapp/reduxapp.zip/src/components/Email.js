import React, { useState } from 'react'

function Email() {
    
    
  return (
    <div>
      <div class="col-md-3">
<label for="formGroupExampleInput" class="form-label">Email ID</label>
  <input type="text" class="form-control" id="formGroupExampleInput"></input>
  </div>
    </div>
  )
}

export default Email
